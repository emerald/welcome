const vc <- object vc
  export operation foobar -> [r : Integer]
    r <- 1001
  end foobar
end vc

export vc

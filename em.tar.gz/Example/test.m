const six <- 6 * 1

const Another <- object Another

  process
    (locate self)$stdout.putString[six.asString]
  end process
end Another

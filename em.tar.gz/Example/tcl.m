const Tree <- class Tree
  field isseq : Boolean <- false
end Tree

export tree

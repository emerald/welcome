const BoolLit <- class Boollit (Tree)
  const field value : Boolean <- false
end boollit

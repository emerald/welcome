const bar <- object bar
  initially
    const x <- foo.create["abcdef\n", stdout]
    x.xxy["defgh\n"]
  end initially
end bar

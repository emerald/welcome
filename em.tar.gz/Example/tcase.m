const tcase <- object tcase
  process
    var i : Integer <- 65364
    if i = 65361 then
      stdout.putstring["1\n"]
    elseif i = 65362 then
      stdout.putstring["1\n"]
    elseif i = 65363 then
      stdout.putstring["1\n"]
    elseif i = 65364 then
      stdout.putstring["1\n"]
    end if
  end process
end tcase

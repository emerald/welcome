const first <- object first
  const target <- object target
    export operation op1 
    end op1
    export operation op2 
    end op2
    export operation op3 
    end op3
    export operation op4 
    end op4
    export operation op5 
    end op5
    export operation op6 
    end op6
    export operation op7 
    end op7
    export operation op8 
    end op8
    export operation op9 
    end op9
    export operation op10 
    end op10
    export operation op11 
    end op11
    export operation op12 
    end op12
    export operation op13 
    end op13
    export operation op14 
    end op14
    export operation op15 
    end op15
    export operation op16 
    end op16
    export operation op17 
    end op17
    export operation op18 
    end op18
    export operation op19 
    end op19
    export operation op20 
    end op20
  end target
  initially
    var i : Integer <- 1
    const limit : Integer <- 1000000
    loop
      exit when i > limit
      target.op19
      i <- i + 1
    end loop
  end initially
end first

const etObjekt <- object enObjektBlokk
 var testVec : Vector.of[Integer]
end enObjektBlokk

const tf <- object tf
  field x : Integer

end tf

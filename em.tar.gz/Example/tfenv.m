
const bar <- 4

const foo <- object foo
  export op banana
  end banana
end foo

export foo 
export bar

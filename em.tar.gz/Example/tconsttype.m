const consttype <- object consttype
  initially
    const y <- msecs.asString
    var msecs : Integer
    const b <- y[4]
  end initially
end consttype

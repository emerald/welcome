#pragma warning(disable: 4068)
#pragma pointer_size long
#include <stdio.h>
#pragma pointer_size short

int main(ac,av)
int ac;
char **av;
{
  mainp(ac,av);
  return 0;
}
